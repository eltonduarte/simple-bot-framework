import subprocess

def program(caminho_programa):
    subprocess.Popen(caminho_programa)

def file():
    ...