from datetime import datetime
import os
from reusable_code import log_to_file

def path_project(BASE_DIR):
    
    timestamp = datetime.now().strftime("%d_%m_%y-%H_%M_%S")

    dict_path = {
        'path_entrada': BASE_DIR / 'entrada',
        'path_saida': BASE_DIR / 'saida',            
        'file_log': BASE_DIR / 'logs' / f'log_{timestamp}.csv',
    }

    
def make_path(dict_path):
    # Cria os diretórios
    for path in dict_path.values():
        os.makedirs(path)
        log_to_file.info(f"Diretório {path} criado com sucesso", f"{dict_path['file_log']}")
    
    return dict_path
